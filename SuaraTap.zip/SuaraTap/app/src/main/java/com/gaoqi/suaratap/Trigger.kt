package com.gaoqi.suaratap

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/** Satu pemicu: kata-kata yang diucapkan -> tekan layar di posisi tertentu. */
data class Trigger(
    val id: String = UUID.randomUUID().toString(),
    val words: List<String>,
    /** Lama tekan (ms). ~50 = tap biasa, 600+ = tekan lama. */
    val holdMs: Int = 50,
    /** Posisi tekan dalam persen lebar/tinggi layar (0..100). */
    val xPct: Float = 50f,
    val yPct: Float = 50f,
    val enabled: Boolean = true,
)

object TriggerStore {
    private const val PREF = "suara_tap"
    private const val KEY_TRIGGERS = "triggers"
    private const val KEY_LANG = "language"
    private const val KEY_OFFLINE = "offline"
    private const val KEY_MUTE = "mute_beep"

    private fun prefs(ctx: Context) = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE)

    fun load(ctx: Context): List<Trigger> {
        val raw = prefs(ctx).getString(KEY_TRIGGERS, null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                val w = o.getJSONArray("words")
                Trigger(
                    id = o.getString("id"),
                    words = (0 until w.length()).map { w.getString(it) },
                    holdMs = o.optInt("holdMs", 50),
                    xPct = o.optDouble("xPct", 50.0).toFloat(),
                    yPct = o.optDouble("yPct", 50.0).toFloat(),
                    enabled = o.optBoolean("enabled", true),
                )
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun save(ctx: Context, list: List<Trigger>) {
        val arr = JSONArray()
        list.forEach { t ->
            arr.put(
                JSONObject()
                    .put("id", t.id)
                    .put("words", JSONArray(t.words))
                    .put("holdMs", t.holdMs)
                    .put("xPct", t.xPct.toDouble())
                    .put("yPct", t.yPct.toDouble())
                    .put("enabled", t.enabled)
            )
        }
        prefs(ctx).edit().putString(KEY_TRIGGERS, arr.toString()).apply()
    }

    fun getLanguage(ctx: Context): String = prefs(ctx).getString(KEY_LANG, "id-ID") ?: "id-ID"
    fun setLanguage(ctx: Context, v: String) = prefs(ctx).edit().putString(KEY_LANG, v).apply()
    fun getOffline(ctx: Context): Boolean = prefs(ctx).getBoolean(KEY_OFFLINE, false)
    fun setOffline(ctx: Context, v: Boolean) = prefs(ctx).edit().putBoolean(KEY_OFFLINE, v).apply()
    fun getMute(ctx: Context): Boolean = prefs(ctx).getBoolean(KEY_MUTE, true)
    fun setMute(ctx: Context, v: Boolean) = prefs(ctx).edit().putBoolean(KEY_MUTE, v).apply()
}

/** Huruf kecil, buang tanda baca, rapikan spasi. Nada/volume suara tidak berpengaruh karena yang dicocokkan adalah teks. */
fun normalizeText(s: String): String =
    s.lowercase()
        .replace(Regex("[^\\p{L}\\p{N}\\s]"), " ")
        .replace(Regex("\\s+"), " ")
        .trim()

/** Hitung berapa kali [word] muncul sebagai kata utuh di [text] (keduanya sudah dinormalisasi). */
fun countWord(text: String, word: String): Int {
    if (word.isEmpty()) return 0
    val hay = " $text "
    val needle = " $word "
    var count = 0
    var i = hay.indexOf(needle)
    while (i >= 0) {
        count++
        i = hay.indexOf(needle, i + word.length + 1)
    }
    return count
}
