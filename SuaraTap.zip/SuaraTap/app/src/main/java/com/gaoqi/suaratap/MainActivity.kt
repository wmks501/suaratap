package com.gaoqi.suaratap

import android.Manifest
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import java.util.Locale

class MainActivity : ComponentActivity() {

    private var resumeTick by mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppState.init(applicationContext)
        setContent {
            MaterialTheme {
                App(resumeTick)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        resumeTick++
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()

    private fun isAccessibilityEnabled(): Boolean {
        val enabled = Settings.Secure.getString(
            contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        val cn = ComponentName(this, TapAccessibilityService::class.java)
        return enabled.split(':').any {
            it.equals(cn.flattenToString(), true) || it.equals(cn.flattenToShortString(), true)
        }
    }

    @OptIn(ExperimentalMaterial3Api::class)
    @Composable
    private fun App(tick: Int) {
        val ctx = this
        val mic = remember(tick) {
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) ==
                PackageManager.PERMISSION_GRANTED
        }
        val notif = remember(tick) {
            Build.VERSION.SDK_INT < 33 ||
                ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) ==
                PackageManager.PERMISSION_GRANTED
        }
        val accSystem = remember(tick) { isAccessibilityEnabled() }
        val acc = accSystem || AppState.accessibilityOn

        val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { resumeTick++ }
        val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { resumeTick++ }

        var showDialog by remember { mutableStateOf(false) }
        var editing by remember { mutableStateOf<Trigger?>(null) }

        Scaffold(topBar = { TopAppBar(title = { Text("Suara Tap") }) }) { pad ->
            LazyColumn(
                modifier = Modifier.padding(pad).fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // ---- Izin ----
                item {
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("Izin yang dibutuhkan", style = MaterialTheme.typography.titleMedium)
                            PermRow("Mikrofon", mic, "Izinkan") {
                                micLauncher.launch(Manifest.permission.RECORD_AUDIO)
                            }
                            PermRow("Notifikasi", notif, "Izinkan") {
                                if (Build.VERSION.SDK_INT >= 33) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                            }
                            PermRow("Accessibility (untuk menekan layar)", acc, "Buka") {
                                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                                toast("Cari \"Suara Tap\" lalu aktifkan")
                            }
                        }
                    }
                }

                // ---- Kontrol ----
                item {
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(AppState.status, style = MaterialTheme.typography.titleMedium)
                            if (AppState.lastHeard.isNotEmpty()) Text("Terdengar: ${AppState.lastHeard}")
                            if (AppState.lastFired.isNotEmpty()) Text("Aksi terakhir: ${AppState.lastFired}")
                            Button(
                                onClick = {
                                    if (AppState.listening) ListenService.stop(ctx)
                                    else ListenService.start(ctx)
                                },
                                enabled = mic,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(if (AppState.listening) "Berhenti" else "Mulai mendengarkan")
                            }
                        }
                    }
                }

                // ---- Pengaturan ----
                item {
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("Pengaturan", style = MaterialTheme.typography.titleMedium)
                            Text("Bahasa pengenalan suara")
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                listOf("id-ID" to "Indonesia", "en-US" to "English").forEach { (code, label) ->
                                    FilterChip(
                                        selected = AppState.language == code,
                                        onClick = { AppState.updateLanguage(ctx, code) },
                                        label = { Text(label) }
                                    )
                                }
                            }
                            SwitchRow("Utamakan offline (hemat data, kurang akurat)", AppState.preferOffline) {
                                AppState.updateOffline(ctx, it)
                            }
                            SwitchRow("Redam bunyi \"bip\" pengenal suara", AppState.muteBeep) {
                                AppState.updateMute(ctx, it)
                            }
                            Text(
                                "Perubahan bahasa/offline berlaku di sesi dengar berikutnya; bunyi bip berlaku saat Mulai.",
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }
                }

                // ---- Daftar pemicu ----
                item {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text("Pemicu", style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
                        Button(onClick = { editing = null; showDialog = true }) { Text("Tambah") }
                    }
                }

                if (AppState.triggers.isEmpty()) {
                    item { Text("Belum ada pemicu. Tekan Tambah, misalnya kata \"tes\".") }
                }

                items(AppState.triggers, key = { it.id }) { t ->
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    t.words.joinToString(" / "),
                                    style = MaterialTheme.typography.titleMedium,
                                    modifier = Modifier.weight(1f)
                                )
                                Switch(checked = t.enabled, onCheckedChange = {
                                    AppState.upsert(ctx, t.copy(enabled = it))
                                })
                            }
                            Text(
                                "Posisi: ${fmt(t.xPct)}%, ${fmt(t.yPct)}%  •  Tekan ${t.holdMs} ms " +
                                    if (t.holdMs < 150) "(tap)" else "(tekan lama)"
                            )
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedButton(onClick = {
                                    val svc = TapAccessibilityService.instance
                                    if (svc == null) {
                                        toast("Aktifkan izin Accessibility dulu")
                                    } else {
                                        toast("Buka game dalam 5 detik, lalu sentuh titik yang diinginkan")
                                        svc.pickPosition(5000) { x, y ->
                                            AppState.triggers.find { it.id == t.id }?.let { cur ->
                                                AppState.upsert(applicationContext, cur.copy(xPct = x, yPct = y))
                                            }
                                        }
                                        moveTaskToBack(true)
                                    }
                                }) { Text("Pilih posisi") }
                                OutlinedButton(onClick = {
                                    val svc = TapAccessibilityService.instance
                                    if (svc == null) {
                                        toast("Aktifkan izin Accessibility dulu")
                                    } else {
                                        toast("Tap akan terjadi dalam 3 detik")
                                        Handler(Looper.getMainLooper()).postDelayed({
                                            svc.tap(t.xPct, t.yPct, t.holdMs)
                                        }, 3000)
                                        moveTaskToBack(true)
                                    }
                                }) { Text("Tes tap") }
                            }
                            Row {
                                TextButton(onClick = { editing = t; showDialog = true }) { Text("Ubah") }
                                TextButton(onClick = { AppState.remove(ctx, t.id) }) { Text("Hapus") }
                            }
                        }
                    }
                }

                item {
                    Text(
                        "Cara pakai: aktifkan Accessibility, tambah pemicu, pilih posisi tekan di game, " +
                            "lalu Mulai mendengarkan dan pindah ke game.",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }

        if (showDialog) {
            TriggerDialog(
                initial = editing,
                onDismiss = { showDialog = false },
                onSave = { AppState.upsert(ctx, it); showDialog = false }
            )
        }
    }
}

private fun fmt(v: Float): String = String.format(Locale.US, "%.1f", v)

@Composable
private fun PermRow(label: String, ok: Boolean, actionLabel: String, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text((if (ok) "✅ " else "❌ ") + label, modifier = Modifier.weight(1f))
        if (!ok) Button(onClick = onClick) { Text(actionLabel) }
    }
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun TriggerDialog(initial: Trigger?, onDismiss: () -> Unit, onSave: (Trigger) -> Unit) {
    var words by remember { mutableStateOf(initial?.words?.joinToString(", ") ?: "") }
    var hold by remember { mutableStateOf((initial?.holdMs ?: 50).toString()) }
    var x by remember { mutableStateOf(fmt(initial?.xPct ?: 50f)) }
    var y by remember { mutableStateOf(fmt(initial?.yPct ?: 50f)) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "Pemicu baru" else "Ubah pemicu") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = words, onValueChange = { words = it },
                    label = { Text("Kata pemicu (pisah dengan koma)") },
                    supportingText = { Text("Contoh: tes, test, tez") }
                )
                OutlinedTextField(
                    value = hold, onValueChange = { hold = it },
                    label = { Text("Lama tekan (ms)") },
                    supportingText = { Text("50 = tap, 600+ = tekan lama") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = x, onValueChange = { x = it },
                        label = { Text("X (%)") }, modifier = Modifier.weight(1f),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
                    )
                    OutlinedTextField(
                        value = y, onValueChange = { y = it },
                        label = { Text("Y (%)") }, modifier = Modifier.weight(1f),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
                    )
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val list = words.split(",").map { it.trim() }.filter { it.isNotEmpty() }
                if (list.isNotEmpty()) {
                    val base = initial ?: Trigger(words = list)
                    onSave(
                        base.copy(
                            words = list,
                            holdMs = hold.toIntOrNull()?.coerceIn(1, 5000) ?: 50,
                            xPct = x.replace(',', '.').toFloatOrNull()?.coerceIn(0f, 100f) ?: 50f,
                            yPct = y.replace(',', '.').toFloatOrNull()?.coerceIn(0f, 100f) ?: 50f,
                        )
                    )
                }
            }) { Text("Simpan") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } }
    )
}
