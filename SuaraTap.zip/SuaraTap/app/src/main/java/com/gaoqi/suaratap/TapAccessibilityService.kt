package com.gaoqi.suaratap

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.ViewGroup
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.FrameLayout
import android.widget.TextView

/** Bertugas menekan layar (tap / tekan lama) dan menyediakan overlay "pilih posisi". */
class TapAccessibilityService : AccessibilityService() {

    companion object {
        var instance: TapAccessibilityService? = null
    }

    private val handler = Handler(Looper.getMainLooper())

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        AppState.accessibilityOn = true
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        AppState.accessibilityOn = false
        return super.onUnbind(intent)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    private fun metrics(): DisplayMetrics {
        val dm = DisplayMetrics()
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealMetrics(dm)
        return dm
    }

    /** Tekan layar di (xPct, yPct) selama holdMs. */
    fun tap(xPct: Float, yPct: Float, holdMs: Int) {
        val dm = metrics()
        val x = dm.widthPixels * xPct / 100f
        val y = dm.heightPixels * yPct / 100f
        val path = Path().apply { moveTo(x, y) }
        val stroke = GestureDescription.StrokeDescription(path, 0L, holdMs.toLong().coerceAtLeast(1L))
        dispatchGesture(GestureDescription.Builder().addStroke(stroke).build(), null, null)
    }

    /**
     * Setelah [delayMs], tampilkan overlay layar penuh. Sentuhan pertama = posisi yang dipilih
     * (dikembalikan dalam persen). Dipakai supaya kamu bisa pindah ke game dulu.
     */
    fun pickPosition(delayMs: Long, onPicked: (Float, Float) -> Unit) {
        handler.postDelayed({
            val wm = getSystemService(WINDOW_SERVICE) as WindowManager
            val root = FrameLayout(this)
            root.setBackgroundColor(0x88000000.toInt())
            val label = TextView(this).apply {
                text = "Sentuh posisi yang diinginkan"
                setTextColor(Color.WHITE)
                textSize = 20f
                gravity = Gravity.CENTER
            }
            root.addView(
                label,
                FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    Gravity.CENTER
                )
            )
            root.setOnTouchListener { _, ev ->
                if (ev.action == MotionEvent.ACTION_UP) {
                    val dm = metrics()
                    val xp = (ev.rawX / dm.widthPixels * 100f).coerceIn(0f, 100f)
                    val yp = (ev.rawY / dm.heightPixels * 100f).coerceIn(0f, 100f)
                    try { wm.removeView(root) } catch (_: Exception) {}
                    onPicked(xp, yp)
                }
                true
            }
            val lp = WindowManager.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
            )
            lp.gravity = Gravity.TOP or Gravity.START
            wm.addView(root, lp)
        }, delayMs)
    }
}
