package com.gaoqi.suaratap

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/** State bersama antara UI, ListenService, dan TapAccessibilityService (semua di main thread). */
object AppState {
    val triggers = mutableStateListOf<Trigger>()
    var listening by mutableStateOf(false)
    var accessibilityOn by mutableStateOf(false)
    var status by mutableStateOf("Belum aktif")
    var lastHeard by mutableStateOf("")
    var lastFired by mutableStateOf("")
    var language by mutableStateOf("id-ID")
    var preferOffline by mutableStateOf(false)
    var muteBeep by mutableStateOf(true)

    private var loaded = false

    fun init(ctx: Context) {
        if (loaded) return
        loaded = true
        triggers.clear()
        triggers.addAll(TriggerStore.load(ctx))
        language = TriggerStore.getLanguage(ctx)
        preferOffline = TriggerStore.getOffline(ctx)
        muteBeep = TriggerStore.getMute(ctx)
    }

    fun upsert(ctx: Context, t: Trigger) {
        val i = triggers.indexOfFirst { it.id == t.id }
        if (i >= 0) triggers[i] = t else triggers.add(t)
        TriggerStore.save(ctx, triggers)
    }

    fun remove(ctx: Context, id: String) {
        triggers.removeAll { it.id == id }
        TriggerStore.save(ctx, triggers)
    }

    fun updateLanguage(ctx: Context, v: String) { language = v; TriggerStore.setLanguage(ctx, v) }
    fun updateOffline(ctx: Context, v: Boolean) { preferOffline = v; TriggerStore.setOffline(ctx, v) }
    fun updateMute(ctx: Context, v: Boolean) { muteBeep = v; TriggerStore.setMute(ctx, v) }
}
