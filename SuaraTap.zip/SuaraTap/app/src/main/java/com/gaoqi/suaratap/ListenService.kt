package com.gaoqi.suaratap

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.media.AudioManager
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat

/**
 * Mendengarkan terus-menerus (speech recognition bawaan Android), mengubah suara jadi teks,
 * lalu mencocokkan teks dengan kata pemicu. Karena yang dicocokkan teks, nada/volume tidak masalah.
 */
class ListenService : Service() {

    companion object {
        private const val CHANNEL = "listen"
        private const val NOTIF_ID = 1
        const val ACTION_STOP = "com.gaoqi.suaratap.STOP"

        fun start(ctx: Context) {
            ContextCompat.startForegroundService(ctx, Intent(ctx, ListenService::class.java))
        }

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, ListenService::class.java))
        }
    }

    private val handler = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var running = false

    /** Jumlah kemunculan tiap kata yang sudah "ditembakkan" pada sesi dengar saat ini. */
    private val fired = HashMap<String, Int>()
    private val lastFireAt = HashMap<String, Long>()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        AppState.init(applicationContext)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        ServiceCompat.startForeground(
            this, NOTIF_ID, buildNotification(),
            ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
        )
        if (!running) begin()
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        running = false
        handler.removeCallbacksAndMessages(null)
        recognizer?.destroy()
        recognizer = null
        muteBeep(false)
        AppState.listening = false
        AppState.status = "Berhenti"
        super.onDestroy()
    }

    private fun buildNotification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Mendengarkan suara", NotificationManager.IMPORTANCE_LOW)
        )
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, ListenService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Suara Tap aktif")
            .setContentText("Mendengarkan kata pemicu…")
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(
                Notification.Action.Builder(
                    Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel),
                    "Berhenti", stop
                ).build()
            )
            .build()
    }

    private fun begin() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            AppState.status = "Speech recognition tidak tersedia (pasang/aktifkan aplikasi Google)"
            stopSelf()
            return
        }
        running = true
        AppState.listening = true
        muteBeep(AppState.muteBeep)
        recreate()
        listen()
    }

    private fun recreate() {
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).also {
            it.setRecognitionListener(listener)
        }
    }

    private fun listen() {
        if (!running) return
        fired.clear()
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, AppState.language)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, AppState.preferOffline)
        }
        try {
            recognizer?.startListening(i)
        } catch (e: Exception) {
            AppState.status = "Gagal mulai mendengar: ${e.message}"
            restartSoon(1000, recreate = true)
        }
    }

    private fun restartSoon(delay: Long, recreate: Boolean = false) {
        handler.removeCallbacksAndMessages(null)
        handler.postDelayed({
            if (!running) return@postDelayed
            if (recreate) recreate()
            listen()
        }, delay)
    }

    private fun muteBeep(mute: Boolean) {
        try {
            val am = getSystemService(AudioManager::class.java)
            val dir = if (mute) AudioManager.ADJUST_MUTE else AudioManager.ADJUST_UNMUTE
            am.adjustStreamVolume(AudioManager.STREAM_NOTIFICATION, dir, 0)
            am.adjustStreamVolume(AudioManager.STREAM_SYSTEM, dir, 0)
        } catch (_: Exception) {
            // Beberapa perangkat menolak (mode Jangan Ganggu). Tidak fatal.
        }
    }

    /** Cocokkan teks hasil dengar dengan semua pemicu. */
    private fun handle(texts: List<String>) {
        if (texts.isEmpty()) return
        val norm = texts.map { normalizeText(it) }
        AppState.lastHeard = norm.first()
        for (t in AppState.triggers) {
            if (!t.enabled) continue
            for (w in t.words) {
                val nw = normalizeText(w)
                if (nw.isEmpty()) continue
                val count = norm.maxOf { countWord(it, nw) }
                val key = t.id + "|" + nw
                val prev = fired[key] ?: 0
                if (count > prev) {
                    fired[key] = count
                    fire(t, nw)
                }
            }
        }
    }

    private fun fire(t: Trigger, word: String) {
        val now = System.currentTimeMillis()
        if (now - (lastFireAt[t.id] ?: 0L) < 250) return
        lastFireAt[t.id] = now
        val svc = TapAccessibilityService.instance
        if (svc == null) {
            AppState.status = "Izin Accessibility belum aktif"
            return
        }
        svc.tap(t.xPct, t.yPct, t.holdMs)
        AppState.lastFired = "\"$word\" → tekan ${t.holdMs} ms"
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) { AppState.status = "Mendengarkan…" }
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onEvent(eventType: Int, params: Bundle?) {}

        override fun onPartialResults(partialResults: Bundle?) {
            handle(partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION).orEmpty())
        }

        override fun onResults(results: Bundle?) {
            handle(results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION).orEmpty())
            restartSoon(100)
        }

        override fun onError(error: Int) {
            when (error) {
                SpeechRecognizer.ERROR_NO_MATCH,
                SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> restartSoon(100)

                SpeechRecognizer.ERROR_RECOGNIZER_BUSY,
                SpeechRecognizer.ERROR_CLIENT -> restartSoon(500, recreate = true)

                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> {
                    AppState.status = "Izin mikrofon belum diberikan"
                    stopSelf()
                }

                12, 13 -> { // LANGUAGE_NOT_SUPPORTED / LANGUAGE_UNAVAILABLE
                    AppState.status = "Bahasa belum tersedia. Matikan mode offline atau unduh paket bahasanya."
                    restartSoon(3000, recreate = true)
                }

                SpeechRecognizer.ERROR_NETWORK,
                SpeechRecognizer.ERROR_NETWORK_TIMEOUT,
                SpeechRecognizer.ERROR_SERVER -> {
                    AppState.status = "Masalah jaringan (mode online butuh internet)"
                    restartSoon(1500, recreate = true)
                }

                else -> restartSoon(500, recreate = true)
            }
        }
    }
}
