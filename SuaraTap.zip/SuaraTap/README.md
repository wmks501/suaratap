# Suara Tap

Aplikasi Android: ucapkan kata pemicu -> HP menekan layar (tap / tekan lama) di posisi yang kamu pilih.
Pakai speech recognition (suara -> teks), jadi nada & volume suara tidak berpengaruh.

## Build
1. Buka folder ini di Android Studio (Ladybug atau lebih baru), tunggu Gradle sync.
2. Colok Redmi 13 (USB debugging aktif) lalu Run, atau Build > Build APK(s) dan instal APK-nya.

## Setup di HP
1. Buka aplikasi, beri izin Mikrofon dan Notifikasi.
2. Tekan "Buka" di baris Accessibility, aktifkan "Suara Tap".
   Kalau tombolnya abu-abu (APK dari luar Play Store): Info aplikasi > titik tiga > "Izinkan setelan terbatas", lalu ulangi.
3. Redmi/HyperOS: Info aplikasi > Hemat baterai > "Tanpa batasan", dan aktifkan Autostart.
4. Tambah pemicu, "Pilih posisi", lalu "Mulai mendengarkan".
